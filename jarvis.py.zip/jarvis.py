import pyttsx3
import speech_recognition as sr
import datetime
import wikipedia
import webbrowser
import os
import random

engine = pyttsx3.init("sapi5")
voices= engine.getProperty("voices")
#print(voices[0].id)
engine.setProperty("voice", voices[0].id)

def speak(audio):
    engine.say(audio)
    engine.runAndWait()

def wishme():
    hour = int(datetime.datetime.now().hour)
    if hour>=0 and hour<12:
        speak("Good Morning!")
    elif hour>=12 and hour<18:
        speak("Good Afternoon!")
    else  :
        speak("Good Evening!")
    
    speak("I am Jarvis. PLease tell me how may i help you")

def takecommand():
    #it will take mic input and give strng output
    r= sr.Recognizer()
    with sr.Microphone() as source:
        print("Listening...")
        r.energy_threshold = 100
        r.pause_threshold = 1.5
        audio = r.listen(source)

    try:
        print("Recognizing....")
        query = r.recognize_google(audio, language= "en-US")
        print(f"User said: {query}\n")

    except Exception as e:
        print("Say that again please...")
        speak("Say that again please")
        return "None"
    return query

if __name__ == "__main__":
    wishme()
    lol= True
    while lol:
        query=takecommand().lower()
    #logic for executing tasks
        if "wikipedia" in query:
            speak("searching wikipedia...")
            query= query.replace("wikipedia", "")
            results  = wikipedia.summary(query, sentences=2)
            speak("According to wikipedia")
            print(results)
            speak(results)
        elif "open youtube" in query:
            webbrowser.open("youtube.com")
        
        elif "open google" in query:
            webbrowser.open("google.com")

        elif "play music" in query:
            music_dr= "H:\\music"
            songs= os.listdir(music_dr)
            #print(songs)
            n= random.randint(0,6)
            os.startfile(os.path.join(music_dr, songs[n]))
        
        elif "the time" in query:
            strtime= datetime.datetime.now().strftime("%H:%M:%S")
            speak(f"sir,the time is {strtime}")
        
        elif "open code" in query:
            code_dr= "H:\\Microsoft VS Code\\Code.exe"
            os.startfile(code_dr)

        elif "quit" in query:
            lol= False
            speak("Bye Abhinav, see you soon")

        elif "bye" in query:
            lol= False
            speak("Bye Abhinav, see you soon")
        
        elif "exit" in query:
            lol= False
            speak("Bye Abhinav, see you soon")
        elif "leave" in query:
            lol= False
            speak("Bye Abhinav, see you soon")

        elif "good night" in query:
            lol= False
            speak("goodnight Abhinav, see you soon")
